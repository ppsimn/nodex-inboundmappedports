import json
import unittest
from copy import deepcopy

from src.sync import SyncManager


def inbound(inbound_id, port, clients, protocol="vless"):
    return {
        "id": inbound_id,
        "port": port,
        "protocol": protocol,
        "settings": json.dumps({"clients": clients}),
    }


def client(client_id, email):
    return {"id": client_id, "email": email, "expiryTime": 0}


class FakeConfig:
    def __init__(self, central, nodes):
        self._central = central
        self._nodes = nodes

    def get_central_server(self):
        return self._central

    def get_nodes(self):
        return self._nodes

    def net(self):
        return {"parallel_node_calls": False, "max_workers": 4}


class FakeTrafficState:
    pass


class FakeAPI:
    def __init__(self, central_inbounds, node_inbounds):
        self.central_inbounds = central_inbounds
        self.node_inbounds = node_inbounds
        self.added_inbounds = []
        self.updated_inbounds = []
        self.deleted_inbounds = []
        self.added_clients = []
        self.updated_clients = []
        self.deleted_clients = []

    def login(self, server):
        return f"session:{server['url']}"

    def get_inbounds(self, server, session):
        if server["url"] == "http://central":
            return deepcopy(self.central_inbounds)
        return deepcopy(self.node_inbounds)

    def add_inbound(self, server, session, inbound_payload):
        payload = deepcopy(inbound_payload)
        self.added_inbounds.append((server["url"], payload))
        created = deepcopy(payload)
        created["id"] = 99
        self.node_inbounds.append(created)

    def update_inbound(self, server, session, inbound_id, inbound_payload):
        payload = deepcopy(inbound_payload)
        self.updated_inbounds.append((server["url"], inbound_id, payload))
        for idx, existing in enumerate(self.node_inbounds):
            if existing["id"] == inbound_id:
                self.node_inbounds[idx] = payload
                break

    def delete_inbound(self, server, session, inbound_id):
        self.deleted_inbounds.append((server["url"], inbound_id))

    def add_client(self, server, session, inbound_id, client_payload):
        self.added_clients.append((server["url"], inbound_id, deepcopy(client_payload)))

    def update_client(self, server, session, client_id, inbound_id, client_payload):
        self.updated_clients.append((server["url"], client_id, inbound_id, deepcopy(client_payload)))

    def delete_client(self, server, session, inbound_id, client_id):
        self.deleted_clients.append((server["url"], inbound_id, client_id))


class SyncMappingTests(unittest.TestCase):
    def test_mapped_sync_updates_target_port_without_touching_unmapped_inbounds(self):
        central = {"url": "http://central", "username": "central", "password": "secret"}
        node = {
            "url": "http://node",
            "username": "node",
            "password": "secret",
            "inbound_mappings": [{"central_port": 8080, "node_port": 8081}],
        }
        api = FakeAPI(
            central_inbounds=[
                inbound(1, 8080, [client("keep", "keep@example.com")]),
                inbound(2, 9090, [client("skip", "skip@example.com")]),
            ],
            node_inbounds=[
                inbound(10, 8081, [client("keep", "keep@example.com"), client("extra", "extra@example.com")]),
                inbound(20, 5555, [client("untouched", "untouched@example.com")]),
            ],
        )

        manager = SyncManager(api, FakeConfig(central, [node]), FakeTrafficState())
        manager.sync_inbounds_and_clients()

        self.assertEqual(len(api.updated_inbounds), 1)
        _, inbound_id, payload = api.updated_inbounds[0]
        self.assertEqual(inbound_id, 10)
        self.assertEqual(payload["id"], 10)
        self.assertEqual(payload["port"], 8081)
        self.assertEqual(api.added_inbounds, [])
        self.assertEqual(api.deleted_inbounds, [])
        self.assertIn(("http://node", "keep", 10, client("keep", "keep@example.com")), api.updated_clients)
        self.assertIn(("http://node", 10, "extra"), api.deleted_clients)
        self.assertFalse(any(call[2] == 1 for call in api.updated_clients))

    def test_mapped_sync_adds_missing_target_without_central_id(self):
        central = {"url": "http://central", "username": "central", "password": "secret"}
        node = {
            "url": "http://node",
            "username": "node",
            "password": "secret",
            "inbound_mappings": [{"central_port": 8080, "node_port": 8081}],
        }
        api = FakeAPI(
            central_inbounds=[inbound(1, 8080, [client("new", "new@example.com")])],
            node_inbounds=[],
        )

        manager = SyncManager(api, FakeConfig(central, [node]), FakeTrafficState())
        manager.sync_inbounds_and_clients()

        self.assertEqual(len(api.added_inbounds), 1)
        _, payload = api.added_inbounds[0]
        self.assertNotIn("id", payload)
        self.assertEqual(payload["port"], 8081)
        self.assertTrue(
            any(call[2] == 99 and call[1] == "new" for call in api.updated_clients) or
            any(call[1] == 99 and call[2] == client("new", "new@example.com") for call in api.added_clients)
        )

    def test_traffic_email_selection_respects_node_mappings(self):
        central = {"url": "http://central"}
        node = {
            "url": "http://node",
            "inbound_mappings": [{"central_port": 8080, "node_port": 8081}],
        }
        manager = SyncManager(None, FakeConfig(central, [node]), FakeTrafficState())

        by_email = manager._traffic_nodes_by_email(
            [
                inbound(1, 8080, [client("selected", "selected@example.com")]),
                inbound(2, 9090, [client("skipped", "skipped@example.com")]),
            ],
            [node],
        )

        self.assertIn("selected@example.com", by_email)
        self.assertNotIn("skipped@example.com", by_email)


if __name__ == "__main__":
    unittest.main()
