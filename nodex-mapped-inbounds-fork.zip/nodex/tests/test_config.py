import json
import os
import tempfile
import unittest
from unittest.mock import patch

from src.config import ConfigManager


class ConfigManagerTests(unittest.TestCase):
    def _write_config(self, payload):
        handle = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8")
        with handle:
            json.dump(payload, handle)
        self.addCleanup(lambda: os.path.exists(handle.name) and os.unlink(handle.name))
        return handle.name

    def test_env_can_define_per_server_api_ports_logins_and_mappings(self):
        config_path = self._write_config({"central_server": {}, "nodes": []})
        env = {
            "CENTRAL_URL": "https://central.example/base/",
            "CENTRAL_API_PORT": "9443",
            "CENTRAL_API_USERNAME": "central-user",
            "CENTRAL_API_PASSWORD": "central-pass",
            "NODE_COUNT": "1",
            "NODE_1_HOST": "node.example",
            "NODE_1_SCHEME": "https",
            "NODE_1_API_ACCESS_PORT": "9444",
            "NODE_1_WEB_PATH": "xui",
            "NODE_1_LOGIN_USERNAME": "node-user",
            "NODE_1_LOGIN_PASSWORD": "node-pass",
            "NODE_1_INBOUND_MAPPINGS": "8080:8081,8443=9443",
        }

        with patch.dict(os.environ, env, clear=True):
            config = ConfigManager(config_path).config

        self.assertEqual(config["central_server"]["url"], "https://central.example:9443/base")
        self.assertEqual(config["central_server"]["username"], "central-user")
        self.assertEqual(config["central_server"]["password"], "central-pass")
        self.assertEqual(config["nodes"][0]["url"], "https://node.example:9444/xui")
        self.assertEqual(config["nodes"][0]["username"], "node-user")
        self.assertEqual(config["nodes"][0]["password"], "node-pass")
        self.assertEqual(
            config["nodes"][0]["inbound_mappings"],
            [
                {"central_port": 8080, "node_port": 8081},
                {"central_port": 8443, "node_port": 9443},
            ],
        )

    def test_json_inbound_mapping_forms_are_normalized(self):
        config_path = self._write_config({
            "central_server": {
                "host": "central.example",
                "api_port": 2053,
                "username": "central",
                "password": "secret",
            },
            "nodes": [
                {
                    "url": "http://node.example:1111/path",
                    "api_port": 2054,
                    "api_username": "node",
                    "api_password": "node-secret",
                    "inbound_mappings": [
                        {"central_port": 8080, "node_port": 8081},
                        {"source_port": "9090", "target_port": "9091"},
                        "10000",
                    ],
                }
            ],
        })

        with patch.dict(os.environ, {}, clear=True):
            config = ConfigManager(config_path).config

        self.assertEqual(config["central_server"]["url"], "http://central.example:2053")
        self.assertEqual(config["nodes"][0]["url"], "http://node.example:2054/path")
        self.assertEqual(config["nodes"][0]["username"], "node")
        self.assertEqual(
            config["nodes"][0]["inbound_mappings"],
            [
                {"central_port": 8080, "node_port": 8081},
                {"central_port": 9090, "node_port": 9091},
                {"central_port": 10000, "node_port": 10000},
            ],
        )


if __name__ == "__main__":
    unittest.main()
