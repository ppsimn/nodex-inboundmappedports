import sys
import types
import unittest

if "requests" not in sys.modules:
    fake_requests = types.SimpleNamespace(Session=lambda: types.SimpleNamespace(headers={}))
    sys.modules["requests"] = fake_requests

from src.api import APIManager


class APIManagerTests(unittest.TestCase):
    def test_session_cache_uses_server_credentials(self):
        manager = APIManager()
        first = manager._get_session({"url": "http://panel.example", "username": "first"})
        first_again = manager._get_session({"url": "http://panel.example/", "username": "first"})
        second = manager._get_session({"url": "http://panel.example", "username": "second"})

        self.assertIs(first, first_again)
        self.assertIsNot(first, second)


if __name__ == "__main__":
    unittest.main()
